# Book Review Web App

## Tech Stack
- Frontend: React.js
- Backend: Node.js, Express.js
- Database: MongoDB
- Auth: JWT

## Setup Instructions

### Backend
```
cd backend
npm install
cp .env.example .env
npm start
```

### Frontend
```
cd frontend
npm install
npm start
```

## Features
- Register/Login (JWT)
- Role-based access: user/admin
- Book listing and reviews
- Admin dashboard for book management

## Demo
Add Google Drive video link here.